"""Modality adapters."""

