"""Training entrypoints and checkpointing."""

